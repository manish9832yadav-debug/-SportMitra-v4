# SportMitra v4 — GitHub APK Build

This repository wraps the SportMitra v4 points-only web prototype in a native Android WebView and includes a GitHub Actions workflow that builds a debug APK.

## Build on GitHub
1. Create a new GitHub repository.
2. Upload all files/folders from this project to the repository root.
3. Push to `main` (or `master`).
4. Open **Actions** → **Build SportMitra APK**.
5. When the workflow finishes, open the run and download **SportMitra-v4-debug-apk** from Artifacts.

You can also start it manually from **Actions → Build SportMitra APK → Run workflow**.

## Prototype notes
- Virtual points only; no deposits, withdrawals, cash-out, or payment processing.
- No OTP/SMS flow.
- Admin prototype credentials are `ankitff` / `Ankit@2007`.
- The admin authentication and points storage are front-end prototype logic, not production-secure authentication/database controls.
